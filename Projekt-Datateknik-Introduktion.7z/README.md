# Projekt-Datateknik-Introduktion
Detta projektet är skapad av Nero Nguyen, Hajir Jawad, Ludvig Svensson, Joshua Sugirtharaj
Projektet är en webbsida som handlar om hållbar utveckling gjord i JavaScript, CSS och HTML
